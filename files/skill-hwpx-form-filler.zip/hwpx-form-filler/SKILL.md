---
name: hwpx-form-filler
description: |
  HWPX 서식파일에 소스파일의 내용을 채워 새 문서를 생성하는 스킬.
  사용자가 두 개의 hwpx 파일을 첨부하고 "서식에 맞춰 만들어줘", "이 서식으로 문서 만들어줘",
  "서식파일에 내용 채워줘", "이 양식에 맞게 작성해줘", "소스 내용을 서식에 넣어줘",
  "○○ 파일을 서식으로 하고 △△ 파일을 참조하여 □□ 만들어" 등의 요청을 할 때 이 스킬을 사용한다.
  두 개의 hwpx 파일이 첨부되었고, 하나는 서식/양식/템플릿이고 다른 하나는 내용/소스/참조인 경우 반드시 이 스킬을 트리거한다.
  "서식", "양식", "템플릿", "소스", "참조", "원본", "내용 채우기", "form", "template" 등의 키워드가
  두 개의 hwpx 파일과 함께 언급되면 이 스킬을 사용한다.
  하나의 hwpx만 첨부되어 다른 주제로 변환하는 경우에도 사용 가능하다(이 경우 서식=소스).
  한글 문서, Hancom, OWPML, .hwpx 파일과 관련된 서식 채우기/변환 요청에 반드시 사용한다.
---

# HWPX 서식 채우기 스킬

두 개의 HWPX 파일(서식파일 + 소스파일)을 받아서, 서식파일의 레이아웃/스타일을 유지한 채 소스파일의 내용을 매핑하여 새 문서를 생성한다.

## 핵심 개념

- **서식파일**: 문서의 뼈대. 레이아웃, 표 구조, 스타일(폰트, 크기, 정렬 등), 항목 체계(목적 → 방침 → 세부계획 등)를 제공한다.
- **소스파일**: 문서의 살. 서식에 채워 넣을 실제 내용(텍스트, 데이터, 항목별 세부 내용)을 제공한다.
- **결과물**: 서식의 틀 + 소스의 내용 = 새 문서. XML 구조(문단 수, 표 행/열, 스타일 ID)는 서식파일과 100% 동일해야 한다.

## 사전 준비: hwpx 스킬 경로 확인

이 스킬은 hwpx 스킬의 스크립트들에 의존한다. 먼저 경로를 찾는다:

```bash
# hwpx 스킬 경로 자동 탐색
HWPX_SKILL_DIR=$(find /sessions -path "*/skills/hwpx" -type d 2>/dev/null | head -1)
echo "HWPX_SKILL_DIR=$HWPX_SKILL_DIR"
# 확인: ls "$HWPX_SKILL_DIR/scripts/analyze_template.py"
```

이하 모든 명령에서 `$HWPX_SKILL_DIR`을 사용한다.

## 워크플로우

### Step 1: 파일 식별 및 복사

사용자가 첨부한 두 파일 중 어느 것이 서식이고 어느 것이 소스인지 파악한다.
사용자가 "A 파일을 서식으로 B 파일을 참조하여"라고 말하면 A=서식, B=소스이다.
파일명에 "서식", "양식", "템플릿" 등이 포함되어 있으면 서식파일일 가능성이 높다.

작업 편의를 위해 /tmp로 복사한다:

```bash
cp "업로드경로/서식파일.hwpx" /tmp/서식.hwpx
cp "업로드경로/소스파일.hwpx" /tmp/소스.hwpx
```

### Step 2: 서식파일 분석

```bash
python3 "$HWPX_SKILL_DIR/scripts/analyze_template.py" /tmp/서식.hwpx
```

분석 결과에서 파악할 것:
- 항목 체계 (번호 헤더, 소제목, 본문 구조)
- 표 구조 (행×열, 열너비, 셀 병합, borderFill)
- 전체 문단 수와 배치
- charPrIDRef, paraPrIDRef 같은 스타일 참조 — 이것들은 절대 변경하지 않는다

### Step 3: 서식파일 텍스트 노드 인덱스 추출

서식파일의 section0.xml에서 모든 `hp:t` 노드를 인덱스로 뽑는다. 이 인덱스가 치환의 기준이 된다:

```python
from lxml import etree
import zipfile

ns = {'hp': 'http://www.hancom.co.kr/hwpml/2011/paragraph'}

with zipfile.ZipFile('/tmp/서식.hwpx') as zf:
    with zf.open('Contents/section0.xml') as f:
        tree = etree.parse(f)
        with open('/tmp/form_section.xml', 'wb') as out:
            tree.write(out, xml_declaration=True, encoding='UTF-8')

texts = tree.xpath('//hp:t', namespaces=ns)
for i, t in enumerate(texts):
    txt = t.text or ''
    print(f"  [{i:3d}] ({len(txt):3d}c) {txt[:80]}")
```

이 출력이 치환 맵의 왼쪽(인덱스 → 현재 텍스트)이 된다.

### Step 4: 소스파일 텍스트 추출

소스파일도 같은 방식으로 텍스트를 추출한다.

**중요**: HWPX 파일에 section이 여러 개 있을 수 있다. section0.xml이 목차이고 section1.xml에 본문이 있는 경우가 흔하다. 반드시 확인한다:

```python
import zipfile
with zipfile.ZipFile('/tmp/소스.hwpx') as zf:
    sections = [n for n in zf.namelist() if 'section' in n.lower()]
    print(sections)  # ['Contents/section0.xml', 'Contents/section1.xml', ...]
```

section이 여러 개면 모든 section의 텍스트를 추출하여 소스 내용의 전체 그림을 파악한다. 소스 텍스트가 많으면 키워드로 핵심 섹션(목적, 방침, 세부계획, 기대효과, 특색사업 등)을 찾아서 읽는다.

### Step 5: 내용 매핑 (핵심 단계)

서식의 각 텍스트 노드에 소스의 어떤 내용이 들어갈지 결정하는 단계이다.
이것이 이 스킬에서 AI의 판단력이 가장 필요한 부분이다.

매핑 원칙:

1. **구조 대응**: 서식의 "목적" 항목에는 소스에서 목적/목표에 해당하는 내용을, "방침"에는 추진 방향/원칙에 해당하는 내용을 매핑한다.
2. **주제 변환**: 소스 내용을 서식의 주제에 맞게 자연스럽게 변환한다. 예를 들어 다문화교육 서식 + 안전교육 소스라면, "다문화 감수성 함양" → "안전의식 함양"으로 바꾸되 문장 구조는 유지한다.
3. **텍스트 길이 매칭**: 각 치환 텍스트의 길이를 원본과 가능한 한 유사하게 맞춘다. page_guard가 문단별 25% 이내, 전체 15% 이내의 편차만 허용하기 때문이다.
4. **빈 노드 보존**: `text=''`이거나 `text=None`인 노드는 치환하지 않는다.
5. **URL은 유사 길이로**: 유튜브 URL 등은 같은 길이의 실제 URL이나 유사 URL로 치환한다.
6. **짧은 텍스트 주의**: 1~5글자 텍스트는 1글자만 달라져도 25%를 넘기 쉽다. 번호("1", "2"), 날짜("9월"), 학년("3학년") 등은 가능하면 같은 글자 수로 맞춘다.

치환 맵 작성 형식:

```python
replacements = {
    0: "새 제목",           # 원본 26c → 새 텍스트도 ~26c
    11: "가. 새 목적 내용",  # 원본 34c → ~34c
    # ... 인덱스: 새 텍스트
}
```

치환하지 않을 노드(구조적 번호 "1","2","3", 빈 노드 등)는 맵에서 제외한다.

### Step 6: XML 텍스트 치환

```python
from lxml import etree

ns = {'hp': 'http://www.hancom.co.kr/hwpml/2011/paragraph'}
tree = etree.parse('/tmp/form_section.xml')
texts = tree.xpath('//hp:t', namespaces=ns)

replacements = {
    # Step 5에서 구성한 매핑
}

for i, t in enumerate(texts):
    if i in replacements:
        t.text = replacements[i]

tree.write('/tmp/new_section.xml', xml_declaration=True, encoding='UTF-8')
print(f"Total text nodes: {len(texts)}, replacements: {len(replacements)}")
```

치환 시 반드시 지킬 것:
- **구조 변경 금지**: 문단/표/셀을 추가·삭제·분할·병합하지 않는다
- **스타일 ID 유지**: charPrIDRef, paraPrIDRef, borderFillIDRef 등을 변경하지 않는다
- **텍스트만 바꾼다**: `t.text = "새 내용"` 외에는 아무것도 건드리지 않는다

### Step 7: 빌드

unpack/pack 방식으로 새 HWPX를 조립한다. (build_hwpx.py는 읽기 전용 템플릿 문제로 권장하지 않는다)

```bash
rm -rf /tmp/unpacked/
python3 "$HWPX_SKILL_DIR/scripts/office/unpack.py" /tmp/서식.hwpx /tmp/unpacked/
cp /tmp/new_section.xml /tmp/unpacked/Contents/section0.xml
python3 "$HWPX_SKILL_DIR/scripts/office/pack.py" /tmp/unpacked/ /tmp/결과.hwpx
```

### Step 8: 검증

```bash
# 구조 검증
python3 "$HWPX_SKILL_DIR/scripts/validate.py" /tmp/결과.hwpx

# 쪽수 드리프트 가드 (서식파일 대비)
python3 "$HWPX_SKILL_DIR/scripts/page_guard.py" \
  --reference /tmp/서식.hwpx \
  --output /tmp/결과.hwpx
```

### Step 9: page_guard 실패 시 수정 루프

page_guard가 실패하면 어떤 문단에서 텍스트 길이 편차가 초과했는지 알려준다.
이 경우 다음 패턴으로 수정한다:

```python
# 1. 실패한 문단의 텍스트 노드 식별
# page_guard 출력에서 "N번째 문단" → 0-indexed로 N-1

ns2 = {'hp': 'http://www.hancom.co.kr/hwpml/2011/paragraph',
       'hs': 'http://www.hancom.co.kr/hwpml/2011/section'}

ref_tree = etree.parse('/tmp/form_section.xml')
out_tree = etree.parse('/tmp/new_section.xml')

ref_paras = ref_tree.getroot().xpath('.//hs:sec/hp:p', namespaces=ns2)
if not ref_paras:
    ref_paras = ref_tree.getroot().xpath('.//hp:p', namespaces=ns2)
out_paras = out_tree.getroot().xpath('.//hs:sec/hp:p', namespaces=ns2)
if not out_paras:
    out_paras = out_tree.getroot().xpath('.//hp:p', namespaces=ns2)

# 실패 문단 번호 (1-indexed)
failing = [54, 65, 76]  # page_guard 출력에서 확인

for idx in failing:
    i = idx - 1
    ref_t = ref_paras[i].xpath('.//hp:t', namespaces=ns2)
    out_t = out_paras[i].xpath('.//hp:t', namespaces=ns2)
    ref_s = ''.join(t.text or '' for t in ref_t)
    out_s = ''.join(t.text or '' for t in out_t)
    print(f"Para {idx}: ref={len(ref_s)}c [{ref_s[:60]}] → out={len(out_s)}c [{out_s[:60]}]")
```

```python
# 2. 해당 텍스트 노드의 글로벌 인덱스를 찾아 수정
texts = out_tree.xpath('//hp:t', namespaces=ns2)
for t in out_t:
    for gi, gt in enumerate(texts):
        if gt is t:
            print(f"  global idx={gi}")
            # 길이를 맞춰서 수정
            gt.text = "길이 맞춘 새 텍스트"
```

수정 후 Step 7~8을 반복한다. 보통 1~2회면 통과한다.

### Step 10: 결과 전달

최종 파일을 사용자의 작업 폴더에 저장하고 링크를 제공한다.

```bash
cp /tmp/결과.hwpx "사용자작업폴더/결과파일명.hwpx"
```

## 특수 케이스

### 서식파일만 있고 소스파일이 없는 경우
사용자가 하나의 hwpx만 첨부하고 "이 서식으로 ○○ 계획 만들어줘"라고 요청하면,
서식파일의 구조를 유지하되 AI가 요청 주제에 맞는 내용을 직접 생성하여 채운다.
동일한 워크플로우(분석→치환→빌드→검증)를 따른다.

### 서식과 소스의 항목 수가 다른 경우
서식에 5개 항목인데 소스에 3개만 있으면 → 2개는 AI가 소스 맥락에 맞게 보충
서식에 3개 항목인데 소스에 5개 있으면 → 3개로 요약/통합하여 서식에 맞춤
핵심 원칙: 서식의 구조(문단 수, 표 행 수)를 절대 변경하지 않는다.

### 표의 행 수가 다른 경우
서식의 표 구조(행 수, 열 수, 셀 병합)를 변경하지 않는다.
소스 데이터를 서식의 행 수에 맞춰 조정한다.
행이 부족하면 핵심 내용 위주로 선별, 행이 남으면 관련 내용으로 채운다.

### 붙임/활동지 페이지가 있는 경우
서식에 붙임(활동지, 첨부자료) 페이지가 있으면, 해당 영역의 텍스트도 새 주제에 맞게 치환한다.
활동지의 제목, 안내문, 빈칸 채우기 문항 등을 새 주제에 맞게 변환하되, 형식(빈칸 괄호, 번호 매기기 등)은 유지한다.

## 의존성

이 스킬은 hwpx 스킬의 다음 스크립트를 사용한다:
- `scripts/analyze_template.py` — HWPX 심층 분석 및 XML 추출
- `scripts/office/unpack.py` — HWPX → 디렉토리 언팩
- `scripts/office/pack.py` — 디렉토리 → HWPX 팩
- `scripts/validate.py` — HWPX 구조 검증
- `scripts/page_guard.py` — 쪽수 드리프트 가드

Python lxml 패키지가 필요하다.
